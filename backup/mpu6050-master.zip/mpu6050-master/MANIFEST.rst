include README.rst
