TODO:

Add:
- Method to disable the temp sensor.
- Methods to change the clock source of the device.
- Implement self test
- Implement (almost) all the features made available by the hardware.

Fix:
- Nothing

Test:
- option for get_accel_data to return in g or in m/s^2.
- Test new docstrings.
- Test this program on the Raspberry Pi 2 Model B.